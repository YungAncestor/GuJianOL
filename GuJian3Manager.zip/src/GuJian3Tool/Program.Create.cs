﻿// -------------------------------------------------------
// © Kaplas. Licensed under MIT. See LICENSE for details.
// -------------------------------------------------------
namespace GuJian3Tool
{
    using System;

    /// <summary>
    /// Create contents functionality.
    /// </summary>
    internal static partial class Program
    {
        private static void Create(Options.Create opts)
        {
            throw new NotImplementedException();
        }
    }
}
