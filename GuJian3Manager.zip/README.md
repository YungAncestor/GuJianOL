# GuJian3Manager
Tools for GuJian 3 files.

Data files are compressed with oodle. You need `oo2core_6_win64.dll` in the app folder.
.xxx files are encrypted with XXTEA encryption. I've been able to get some encryption keys using x64dbg.
